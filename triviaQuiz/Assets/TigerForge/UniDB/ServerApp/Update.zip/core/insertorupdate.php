<?php

include_once("core.php");

$exists = $database->has($CORE["dbTable"], $CORE["where"]);

if ($exists)
{
    $result = $database->update($CORE["dbTable"], $CORE["data"], $CORE["where"]);
    OK("U|" . $result->rowCount(), $database->last());
}
else {
    $result = $database->insert($CORE["dbTable"], $CORE["data"]);
    OK("I|" . $database->id(), $database->last());
}




