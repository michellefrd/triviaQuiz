<?php

include_once("core.php");

$result = $database->update($CORE["dbTable"], $CORE["data"], $CORE["where"]);

OK($result->rowCount(), $database->last());

