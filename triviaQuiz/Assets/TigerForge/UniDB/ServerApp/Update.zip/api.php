<?php

include_once("admin.php");
include_once("Medoo.php");

use Medoo\Medoo;

$_VERSION = "1.2";

$api = $_POST["api"];
$data = $_POST["data"];
$headers = array_change_key_case(getallheaders(), CASE_LOWER);
$systemFolder = "sys/";
if (!file_exists($systemFolder)) mkdir($systemFolder);
$dbConfigFile = $systemFolder . "dbconfigs.php";
$classNamesList = array();

switch ($api) {
    case 'login':

        if ($data["username"] == $_U["username"] && $data["password"] == $_U["password"]) {
            response("OK", $_U["token"]);
        } else {
            response("ERROR", "");
        }
        break;

    case 'db/add':

        if (file_exists($dbConfigFile)) {
            $content = file($dbConfigFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            array_shift($content);
            $result = [];
            $result[] = "<?php die(); ?>\n";
            $newDataAdded = false;
            foreach ($content as $line) 
            {                
                $db = json_decode($line);
                $newData = json_decode($data["data"], true);

                if ($db->dbID == $newData["dbID"]) {
                    $db->dbType = $newData["dbType"];
                    $db->dbName = $newData["dbName"];
                    $db->dbHost = $newData["dbHost"];
                    $db->dbUser = $newData["dbUser"];
                    $db->dbPass = $newData["dbPass"];
                    $db->dbPort = $newData["dbPort"];
                    $db->dbCharset = $newData["dbCharset"];
                    $db->dbCollation = $newData["dbCollation"];
                    $result[] = json_encode($db) . "\n";
                    $newDataAdded = true;
                } else {
                    $result[] = $line . "\n";
                }
            }
            if (!$newDataAdded) {
                $db = json_decode($data["data"], true);
                $result[] = json_encode($db) . "\n";
            }
        } else {
            $result = [];
            $result[] = "<?php die(); ?>\n";
            $db = json_decode($data["data"], true);
            $result[] = json_encode($db) . "\n";
        }

        $dbconfigs = file_put_contents($dbConfigFile, $result);
        response(($dbconfigs === false) ? "ERROR" : "OK", "");
        break;

    case "db/test":

        $db = json_decode($data["data"]);
        $r = scanDB($db);
        if (strpos($r, "|OK") === false) response("ERROR", $r);
        else response("OK", $r);

        break;

    case "db/enable":

        $checked = $data["checked"];
        $id = $data["id"];
        $dbconfigs = file($dbConfigFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $id = $data["id"];
        if ($dbconfigs === false) {
            response("ERROR", "");
        } else {
            $newArray = [];
            foreach ($dbconfigs as $db) {
                if (strpos($db, $id) === false) {
                    $newArray[] = $db . "\n";
                } else {
                    $old = '"dbEnabled":' . ($checked == "true" ? "false" : "true");
                    $new = '"dbEnabled":' . ($checked == "true" ? "true" : "false");
                    $newArray[] = str_replace($old, $new, $db) . "\n";
                }
            }
            $dbconfigs = file_put_contents($dbConfigFile, $newArray);
            response(($dbconfigs === false) ? "ERROR" : "OK", "$checked $old $new");
        }
        break;

    case 'db/list':

        if (!file_exists($dbConfigFile)) response("OK", []);
        $dbconfigs = file($dbConfigFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($dbconfigs !== false) array_shift($dbconfigs);
        response(($dbconfigs === false) ? "ERROR" : "OK", $dbconfigs);
        break;

    case 'db/del':

        $dbconfigs = file($dbConfigFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $id = $data["id"];
        if ($dbconfigs === false) {
            response("ERROR", "");
        } else {
            $newArray = [];
            foreach ($dbconfigs as $db) {
                if (strpos($db, $id) === false) $newArray[] = $db . "\n";
            }
            $dbconfigs = file_put_contents($dbConfigFile, $newArray);
            response(($dbconfigs === false) ? "ERROR" : "OK", "$id");
        }
        break;

    case "unidb/scan":

        if (!file_exists($dbConfigFile)) {
            response("ERROR", "[NO_DATA]");
            return;
        }
        $dbconfigs = file($dbConfigFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($dbconfigs === false) {
            response("ERROR", "");
        } else {
            array_shift($dbconfigs);
            $result = [];
            $hasErrors = false;
            foreach ($dbconfigs as $db) {
                $db = json_decode($db);
                if ($db->dbEnabled) {
                    $r = scanDB($db);
                    if (strpos($r, "|OK") === false) $hasErrors = true;
                    $result[] = $r;
                }
            }
        }
        response(($hasErrors) ? "ERROR" : "OK", $result);
        break;

    case "unidb/generate":

        $C = "";
        $profiles = "";
        $classNamesList = array();

        $profiles .= "<?php\n\n";
        $profiles .= '$PROFILE = [];' . "\n\n";

        $C .= "// ===========================================\n";
        $C .= "//     UniDB - Unity Settings script ($_VERSION)\n";
        $C .= "// ===========================================\n";
        $C .= "\n";
        $C .= "using System;\n\n";
        $C .= "namespace TigerForge.UniDB\n";
        $C .= "{\n";
        $C .= summary("The collection of all your Databases.");
        $C .= "public class UniDB\n";
        $C .= "{\n\n";

        $dbconfigs = file($dbConfigFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($dbconfigs === false) {
            response("ERROR", "");
        } else {
            array_shift($dbconfigs);
            foreach ($dbconfigs as $db) {
                $db = json_decode($db);
                if ($db->dbEnabled) $C .= configDB($db);

                $profiles .= '$P = [];' . "\n";
                $profiles .= '$P["type"] = "' . $db->dbType . '";' . "\n";
                $profiles .= '$P["name"] = "' . $db->dbName . '";' . "\n";
                $profiles .= '$P["host"] = "' . $db->dbHost . '";' . "\n";
                $profiles .= '$P["user"] = "' . $db->dbUser . '";' . "\n";
                $profiles .= '$P["pass"] = "' . $db->dbPass . '";' . "\n";
                $profiles .= '$P["port"] = "' . $db->dbPort . '";' . "\n";
                if (isset($db->dbCharset)) {
                    $profiles .= '$P["charset"] = "' . $db->dbCharset . '";' . "\n";
                    $profiles .= '$P["collation"] = "' . $db->dbCollation . '";' . "\n";
                }
                else {
                    $profiles .= '$P["charset"] = "utf8mb4";' . "\n";
                    $profiles .= '$P["collation"] = "utf8mb4_general_ci";' . "\n";
                }
                $profiles .= '$PROFILE["' . $db->dbID . '"] = $P;' . "\n\n";
            }
        }

        $C .= "\n}\n";
        $C .= "}\n";

        $profiles .= "?>";
        $dbprofiles = file_put_contents($systemFolder . "profiles.php", $profiles);
        if ($dbprofiles === false) response("ERROR", ""); else response("OK", $C);

        break;

    default:
        break;
}

response("ERROR", $_POST, "Invalid HTTP request");

function configDB($db)
{
    global $_U;

    try {
        $C = "";

        $config = [
            'type' => $db->dbType,
            'host' => $db->dbHost,
            'database' => $db->dbName,
            'username' => $db->dbUser,
            'password' => $db->dbPass,
            'error' => PDO::ERRMODE_SILENT
        ];
        if ($db->dbPort != "") $config['port'] = $db->dbPort;

        $database = new Medoo($config);

        $className = getClassName($db);
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $actual_link = rtrim($actual_link, "api.php");

        $C .= "//====================================================================================\n";
        $C .= "// DATABASE: " . basename($db->dbName) . "\n";
        $C .= "//====================================================================================\n\n";

        $C .= summary("[" . strtoupper(getDBType($db->dbType)) . "] " . basename($db->dbName));

        $C .= "public class $className : Database {\n";
        $C .= "public readonly new string Key = \"" . $_U["token"] . "|" . $_U["key"] . "|" . $actual_link . "\";\n";
        $C .= "public readonly new string ID = \"" . $db->dbID . "\";\n";
        $C .= "public readonly new string Type = \"" . $db->dbType . "\";\n";
        $C .= "public override string GetKey() { return Key; }\n";
        $C .= "public override string GetID() { return ID; }\n";
        $C .= "public override string GetDBType() { return Type; }\n";

        $tables = configDBGetTables($database, $db);
        $C .= $tables["C"];

        $C .= "\n\n//====================================================================================\n";
        foreach($tables["DB"] as $tn) { 
            $C .= summary("[" . strtoupper(getDBType($db->dbType)) . "] " . basename($db->dbName) . " » $tn");
            $C .= "public $tn GetTable_$tn() { return new $tn(this); }\n"; 
        }
        $C .= "//====================================================================================\n";

        $C .= "}\n\n";

        return $C;
    } catch (PDOException $e) {
        return "";
    }
}

function getClassName($db) 
{
    global $classNamesList;
    $name = ($db->dbType == "sqlite") ? basename($db->dbName, ".db") : $db->dbName;
    $name = ucfirst(preg_replace("/[^A-Za-z0-9 ]/", '', $name));
    
    if (in_array($name, $classNamesList)) {
        $counter = array_count_values($classNamesList);
        $newName = $name . ($counter[$name]);
    }
    else {
        $newName = $name;
    }

    $classNamesList[] = $name;

    return $newName;
}

function configDBGetTables($database, $db)
{
    $columns = [];

    switch ($db->dbType) {
        case 'mysql':
        case 'mariadb':

            $tables = $database->query("SHOW TABLES");
            if ($tables != null) $tables = $tables->fetchAll();
            foreach ($tables as $t) {
                $tableName = $t[0];
                $columnsList = $database->query("SELECT COLUMN_NAME,COLUMN_DEFAULT,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,NUMERIC_PRECISION from information_schema.columns where table_name = '$tableName' AND table_schema = '$db->dbName'");
                if ($columnsList != null) {
                    $columnsList = $columnsList->fetchAll();
                    foreach ($columnsList as $c) {
                        $data = array();
                        $data["name"] = $c["COLUMN_NAME"];
                        $data["type"] = $c["DATA_TYPE"];
                        $data["length"] = $c["CHARACTER_MAXIMUM_LENGTH"];
                        $data["precision"] = $c["NUMERIC_PRECISION"];
                        $data["default"] = $c["COLUMN_DEFAULT"];
                        $data["isNullable"] = $c["IS_NULLABLE"] == "YES";
                        $columns[$tableName][] = $data;
                    }
                }
            }

            break;

        case 'sqlite':

            $tables = $database->query("SELECT name FROM sqlite_master WHERE type ='table' AND name NOT LIKE 'sqlite_%'");
            if ($tables != null) $tables = $tables->fetchAll();
            foreach ($tables as $t) {
                $tableName = $t[0];
                $columnsList = $database->query("PRAGMA table_info ('$tableName')");
                if ($columnsList != null) {
                    $columnsList = $columnsList->fetchAll();
                    foreach ($columnsList as $c) {
                        $data = array();
                        $data["name"] = $c["name"];
                        $data["type"] = $c["type"];
                        $data["length"] = "";
                        $data["precision"] = "";
                        $data["default"] = $c["dflt_value"];
                        $data["isNullable"] = $c["notnull"] == 1;
                        $columns[$tableName][] = $data;
                    }
                }
            }

            break;

        case 'pgsql':

            $tables = $database->query("SELECT table_name FROM information_schema.tables where table_schema='public'");
            if ($tables != null) $tables = $tables->fetchAll();
            foreach ($tables as $t) {
                $tableName = $t[0];
                $columnsList = $database->query("SELECT column_name,data_type,is_nullable,character_maximum_length,numeric_precision,column_default FROM information_schema.columns WHERE table_name = '$tableName'");
                if ($columnsList != null) {
                    $columnsList = $columnsList->fetchAll();
                    foreach ($columnsList as $c) {
                        $data = array();
                        $data["name"] = $c["column_name"];
                        $data["type"] = $c["data_type"];
                        $data["length"] = $c["character_maximum_length"];
                        $data["precision"] = $c["numeric_precision"];
                        $data["default"] = $c["column_default"];
                        $data["isNullable"] = $c["is_nullable"] == "YES";
                        $columns[$tableName][] = $data;
                    }
                }
            }
            break;

        case 'mssql':

            $tables = $database->query("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE'");
            if ($tables != null) $tables = $tables->fetchAll();
            foreach ($tables as $t) {
                $tableName = $t[0];
                $columnsList = $database->query("SELECT column_name,data_type,is_nullable,character_maximum_length,numeric_precision,column_default FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '$tableName'");
                if ($columnsList != null) {
                    $columnsList = $columnsList->fetchAll();
                    foreach ($columnsList as $c) {
                        $data = array();
                        $data["name"] = $c["column_name"];
                        $data["type"] = $c["data_type"];
                        $data["length"] = $c["character_maximum_length"];
                        $data["precision"] = $c["numeric_precision"];
                        $data["default"] = $c["column_default"];
                        $data["isNullable"] = $c["is_nullable"] == "YES";
                        $columns[$tableName][] = $data;
                    }
                }
            }
            break;

        default:
            break;
    }

    $C = "";
    $DBConstructor = [];

    foreach ($columns as $tableName => $data) 
    {
        $CL = "";
        $R = "";
        foreach ($data as $d) {

            $dataType = mapDataType($d["type"]);
            if ($d["isNullable"]) {
                $dataType = str_replace("Nullable<", "", $dataType);
                $dataType = str_replace(">", "", $dataType);
            }

            $R .= summary("[" . basename($db->dbName) . " » $tableName] ".$d["name"]." (".$d["type"]." | ".str_replace(["<", ">"], [" ", ""], $dataType).")");
            $R .= "public " . $dataType . " " . $d["name"] . ";\n";
            $CL .= summary("[" . basename($db->dbName) . " » $tableName] ".$d["name"]." (".$d["type"]." | ".str_replace(["<", ">"], [" ", ""], $dataType).")");
            $CL .= "public Column " . $d["name"] . " = new (\"" . $d["name"] . "\", \"$tableName\");\n";
        }

        $C .= "\n\n//------------------------------------------------------------------------------------\n";
        $C .= "// TABLE: $tableName\n";
        $C .= "//------------------------------------------------------------------------------------\n";

        $C .= "public class " . ucfirst($tableName) . " : Table {\n";
        $C .= "public class Record {\n";
        $C .= $R;
        $C .= "}\n";
        $C .= summary("This Table Record structure.");
        $C .= "public Record R = new();\n\n";
        $C .= "public class Columns {\n";
        $C .= $CL;
        $C .= "}\n";
        $C .= summary("This Table Columns with built-in functionalities.");
        $C .= "public Columns C = new();\n";
        $C .= "public readonly new string name = \"" . $tableName . "\";\n";
        $C .= "public readonly new Database parent;\n";
        $C .= "public override string GetName() { return name; }\n";
        $C .= "public override Database GetParent() { return parent; }\n";
        $C .= "public " . ucfirst($tableName) . "(Database p) { parent = p; }\n";
        $C .= "}\n\n";

        $DBConstructor[] = ucfirst($tableName);
    }

    return ["C" => $C, "DB" => $DBConstructor];
}

function summary($summary) {
    $C = "";
    $C .= "/// <summary>\n";
    $C .= "/// $summary\n";
    $C .= "/// </summary>\n";
    return $C;
}

function mapDataType($type)
{

    $type = strtolower($type);

    // MySQL / MariaDB
    if ($type == "bool") return "Nullable<Boolean>";
    if ($type == "boolean") return "Nullable<Boolean>";
    if ($type == "bit") return "Nullable<Boolean>";
    if ($type == "tinyint") return "Nullable<SByte>";
    if ($type == "tinyint unsigned") return "Nullable<Byte>";
    if ($type == "smallint") return "Nullable<Int16>";
    if ($type == "year") return "Nullable<Int16>";
    if ($type == "int") return "Nullable<Int32>";
    if ($type == "integer") return "Nullable<Int32>";
    if ($type == "smallint unsigned") return "Nullable<Int32>";
    if ($type == "mediumint") return "Nullable<Int32>";
    if ($type == "bigint") return "Nullable<Int64>";
    if ($type == "int unsigned") return "Nullable<Int64>";
    if ($type == "integer unsigned") return "Nullable<Int64>";
    if ($type == "bit") return "Nullable<Int64>";
    if ($type == "float") return "Nullable<Single>";
    if ($type == "double") return "Nullable<double>";
    if ($type == "real") return "Nullable<double>";
    if ($type == "decimal") return "Nullable<Decimal>";
    if ($type == "numeric") return "Nullable<Decimal>";
    if ($type == "dec") return "Nullable<Decimal>";
    if ($type == "fixed") return "Nullable<Decimal>";
    if ($type == "bigint unsigned") return "Nullable<Decimal>";
    if ($type == "float unsigned") return "Nullable<Decimal>";
    if ($type == "double unsigned") return "Nullable<Decimal>";
    if ($type == "serial") return "Nullable<Decimal>";
    if ($type == "date") return "Nullable<DateTime>";
    if ($type == "timestamp") return "Nullable<DateTime>";
    if ($type == "datetime") return "Nullable<DateTime>";
    if ($type == "datetimeoffset") return "Nullable<DateTimeOffset>";
    if ($type == "time") return "Nullable<DateTime>";
    if ($type == "char") return "string";
    if ($type == "varchar") return "string";
    if ($type == "tinytext") return "string";
    if ($type == "text") return "string";
    if ($type == "mediumtext") return "string";
    if ($type == "longtext") return "string";
    if ($type == "set") return "string";
    if ($type == "enum") return "string";
    if ($type == "nchar") return "string";
    if ($type == "national char") return "string";
    if ($type == "nvarchar") return "string";
    if ($type == "national varchar") return "string";
    if ($type == "character varying") return "string";
    if ($type == "binary") return "byte[]";
    if ($type == "varbinary") return "byte[]";
    if ($type == "tinyblob") return "byte[]";
    if ($type == "blob") return "byte[]";
    if ($type == "mediumblob") return "byte[]";
    if ($type == "longblob") return "byte[]";
    if ($type == "char byte") return "byte[]";

    // PostgreSQL
    if ($type == "bigint") return "Nullable<Int64>";
    if ($type == "bit") return "Nullable<Boolean>";
    if ($type == "boolean") return "Nullable<Boolean>";
    if ($type == "bytea") return "byte[]";
    if ($type == "character") return "string";
    if ($type == "character varying") return "string";
    if ($type == "date") return "Nullable<DateTime>";
    if ($type == "double precision") return "Nullable<Single>";
    if ($type == "integer") return "Nullable<Int32>";
    if ($type == "money") return "Nullable<Decimal>";
    if ($type == "numeric") return "Nullable<Decimal>";
    if ($type == "real") return "Nullable<Single>";
    if ($type == "serial") return "Nullable<Int32>";
    if ($type == "smallint") return "Nullable<Int16>";
    if ($type == "smallserial") return "Nullable<Int16>";
    if ($type == "text") return "string";
    if ($type == "time") return "Nullable<DateTime>";
    if ($type == "timestamp") return "Nullable<DateTime>";

    // SQLite
    if ($type == "numeric") return "Nullable<Decimal>";
    if ($type == "text") return "string";
    if ($type == "integer") return "Nullable<Int32>";
    if ($type == "blob") return "byte[]";
    if ($type == "real") return "Nullable<double>";

    // MSSQL
    if (strpos($type, "datetime") !== false) return "Nullable<DateTime>";
    if (strpos($type, "varchar") !== false) return "Nullable<DateTime>";


    return "string";
}

function scanDB($db)
{

    try {
        $config = [
            'type' => $db->dbType,
            'host' => $db->dbHost,
            'database' => $db->dbName,
            'username' => $db->dbUser,
            'password' => $db->dbPass,
            'error' => PDO::ERRMODE_SILENT
        ];
        if ($db->dbPort != "") $config['port'] = $db->dbPort;

        $database = new Medoo($config);

        return $db->dbID . "|OK";
    } catch (PDOException $e) {
        return $db->dbID . "|" . $e->getMessage();
    }
}

function getDBType($name) {
    if ($name == "mysql") return "MySQL";
    if ($name == "mariadb") return "MariaDB";
    if ($name == "mssql") return "MSSQL";
    if ($name == "oracle") return "Oracle";
    if ($name == "sqlite") return "SQLite";
    if ($name == "pgsql") return "PostgreSQL";
    if ($name == "sybase") return "Sybase";
    return $name;
}

function response($status, $data = "", $error = "")
{
    $response = [];
    $response["status"] = $status;
    $response["data"] = $data;
    $response["error"] = $error;

    die(json_encode($response));
}
