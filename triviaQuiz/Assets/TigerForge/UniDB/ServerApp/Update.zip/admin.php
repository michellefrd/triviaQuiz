<?php
    $_U = [];
    $_U["username"] = "stefano";
    $_U["password"] = "Terrana76!";
    $_U["key"] = "uf0acXzVrnaN6sGZ1U6TQchTC9tTcJ0b";
    $_U["token"] = "4KBvmHpmhI";
?>
