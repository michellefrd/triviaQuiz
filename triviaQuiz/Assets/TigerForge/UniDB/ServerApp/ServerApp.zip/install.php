<?php
$_VERSION = "1.2";

$showTestTitle = true;
$showTestResults = false;
$page = "TEST";
$folderNewName = "";
$folderRename = false;
$hasIssues = false;
$test = [];
$action = "";

if (isset($_GET["action"])) {

    $action = $_GET["action"];
    switch ($action) {
        case 'TEST':

            $fileWrite = file_put_contents("test.txt", "TEST");
            $fileRead = file_get_contents("test.txt");
            $fileDelete = unlink("test.txt");

            $folderCreate = mkdir("test");
            $folderFileWrite = file_put_contents("test/test.txt", "TEST");
            $folderFileRead = file_get_contents("test/test.txt");
            $folderFileDelete = unlink("test/test.txt");
            $folderRename = rename("test", "test2");
            $folderDelete = rmdir("test2");

            $headAllHeaders = function_exists('getallheaders');
            $phpVersion = PHP_VERSION;
            $versionOK = version_compare(PHP_VERSION, '7.4.0') >= 0;

            $test = [];
            $test[] = ["File WRITE", $fileWrite, "I can write files.", "I can't write files (1)"];
            $test[] = ["File READ", $fileRead, "I can read files.", "I can't read files (1)"];
            $test[] = ["File DELETE", $fileDelete, "I can delete files.", "I can't delete files (1)"];

            $test[] = ["Folder CREATE", $folderCreate, "I can create folders.", "I can't create folders (1)"];
            $test[] = ["Folder file WRITE", $folderFileWrite, "I can write into folders.", "I can't write into folders (1)"];
            $test[] = ["Folder file READ", $folderFileRead, "I can read into folder.", "I can't read into folders (1)"];
            $test[] = ["Folder file DELETE", $folderFileDelete, "I can delete into folder.", "I can't delete into folders (1)"];
            $test[] = ["Folder RENAME", $folderRename, "I can rename folders.", "I can't rename folders (1)"];
            $test[] = ["Folder DELETE", $folderDelete, "I can delete folders.", "I can't delete folders (1)"];

            $test[] = ["getallheaders()", $headAllHeaders, "I can read the Header data.", "I can't read the Header data (2)"];
            $test[] = ["PHP version $phpVersion", $versionOK, "Your PHP version is ok.", "Your PHP version must be updated (3)"];

            $hasIssues = false;
            foreach ($test as $t) if ($t[1] === false) $hasIssues = true;
            $showTestTitle = $hasIssues;
            $showTestResults = true;

            break;

        case 'START':

            $showTestTitle = false;
            $showTestResults = false;
            $page = "START";

            break;

        case 'INSTALL':

                $showTestTitle = false;
                $showTestResults = false;
                $page = "START";

                $folderNewName = generateRandomString();
                $folderRename = rename("tmp", $folderNewName);

                $key = generateRandomString(32);
                $token = generateRandomString();
                
                $HTML = '<?php' . "\n";
                $HTML .= '    $_U = [];' . "\n";
                $HTML .= '    $_U["username"] = "' . base64_decode($_GET["u"]) . '";' . "\n";
                $HTML .= '    $_U["password"] = "' . base64_decode($_GET["p"]) . '";' . "\n";
                $HTML .= '    $_U["key"] = "' . $key . '";' . "\n";
                $HTML .= '    $_U["token"] = "' . $token . '";' . "\n";
                $HTML .= '?>' . "\n";
                $adminFile = file_put_contents("$folderNewName/admin.php", $HTML);

                $fileRename = rename("install.php", "install_" . generateRandomString() . ".php");
                break;

        default:
            break;
    }

}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>

<!doctype html>
<html>

<head>
    <title>TigerForge™ UniDB | INSTALLER</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" type="image/x-icon" href="favicon.ico">

    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.37/dist/sweetalert2.all.min.js"></script>

    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #272727;
            color: #CCC;
            font-family: Roboto;
        }

        .page {
            display: flex;
            flex-direction: column;
        }

        .banner {
            display: flex;
            width: 100%;
        }

        .banner i {
            color: darkorange;
        }

        .banner>div:nth-child(1) {
            background-color: #3E3E3E;
            padding: 10px;
        }

        .banner>div:nth-child(2) {
            background-color: #4A4A4A;
            padding: 10px;
            flex-grow: 1;
            display: flex;
            align-items: center;
            font-size: 26px;
        }

        .banner>div:nth-child(3) {
            background-color: #4A4A4A;
            padding: 10px;
            display: flex;
            align-items: center;
            font-size: 10px;
            color: #8C8C8C;
        }

        .banner span {
            font-weight: bold;
            color: white;
        }

        .body {
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .body .title {
            color: orange;
            font-size: 18px;
            margin-bottom: 6px;
        }

        .body .desc {
            font-size: 14px;
            font-style: italic;
        }

        .body button {
            background-color: #0390BB;
            padding: 10px;
            border-radius: 4px;
            border: none;
            width: fit-content;
            transition: all 0.2s ease-out;
            cursor: pointer;
            margin-top: 10px;
            color: white;
            font-family: Roboto;
        }

        .body button:hover {
            background-color: #3CB9DF;
        }

        .body .btInstall {
            background-color: #199B06;
            padding: 10px;
            border-radius: 4px;
            border: none;
            width: fit-content;
            transition: all 0.2s ease-out;
            cursor: pointer;
            color: white;
            margin-top: 0px;
            font-family: Roboto;
        }

        .body .btInstall:hover {
            background-color: #23BD0B;
        }

        .body .test {
            margin-top: 40px;
            width: 700px;
            flex-direction: column;
        }

        .body .test>:nth-child(1) {
            margin-bottom: 20px;
        }

        .body .test>:nth-child(1) .success {
            padding: 20px;
            background-color: #03441c;
            color: white;
            display: flex;
            margin-top: -30px;
        }

        .body .test>:nth-child(1) .warning {
            padding: 20px;
            background-color: #620000;
            color: white;
            display: flex;
        }

        .body .test>:nth-child(2) {
            background-color: #555;
            border-radius: 4px 4px 0px 0px;
            padding: 8px;
            font-size: 16px;
            font-weight: bold;
            color: white;
        }

        .body .test .row1 {
            display: flex;
            background-color: #3c3c3c;
            font-size: 14px;
        }

        .body .test .row1>div:nth-child(1) {
            width: 150px;
            box-sizing: border-box;
            padding: 8px;
        }

        .body .test .row1>div:nth-child(2) {
            width: 60px;
            box-sizing: border-box;
            padding: 8px;
            text-align: center;
        }

        .body .test .row1>div:nth-child(3) {
            flex-grow: 1;
            box-sizing: border-box;
            padding: 8px;
        }

        .body .test up {
            font-size: 12px;
            display: block;
            float: right;
            color: #ff8f00;
        }

        .body .form {
            margin-top: 10px;
            margin-bottom: 10px;
            margin-left: 20px;
        }

        .body .form label {
            font-weight: bold;
            font-size: 14px;
            color: #ffec84;
        }

        .body .form .desc {
            font-size: 12px;
            font-style: normal;
            margin: 4px 0px;
        }

        .body .title2 {
            font-weight: 100;
            color: #029ece;
            padding-top: 24px;
        }

        body .form input {
            margin-top: 6px;
            background-color: #3e3e3e;
            border: 1px solid #555;
            border-radius: 4px;
            padding: 10px;
            color: white;
            width: 400px;
            padding-left: 42px;
            outline: 0;
        }

        .body .form .icon {
            position: absolute;
            top: 17px;
            left: 14px;
            color: #ffec84;
        }

        .body .install-info {
            padding: 20px;
            background-color: #1e1e1e;
            border-radius: 6px;
            width: 300px;
            margin-right: 20px;
        }

        .body .bt-blue {
            color: #00c3ff;
        }
        .body .bt-green {
            color: #21ff00;
        }
        .body .bt-red {
            color: #ffbec2;
        }
    </style>

</head>

<body>
    <div class="page">

        <div class="banner">
            <div>
                <i class="fa-solid fa-user-gear fa-3x"></i>
            </div>
            <div>
                <div><span>UniDB</span> Server App Installation</div>
            </div>
            <div>
                <div>v.<?= $_VERSION ?></div>
            </div>
        </div>

        <div class="body" style="display: <?= ($page == "TEST") ? "inline" : "none" ?>;">

            <span style="display: <?= $showTestTitle ? "inline" : "none" ?>;">
                <div class="title"><i class="fa-solid fa-server"></i> <b>SERVER TEST</b></div>
                <div class="desc">
                I have to perform some <b>reading/writing tests</b> in your web hosting to check if everything works correctly before installation.
                    <br>
                    Click the <span class="bt-blue">[START TEST]</span> button below to run the test procedure.
                </div>
                <button onclick="start()">START TEST</button>
            </span>

            <div class="test" style="display: <?= $showTestResults ? "flex" : "none" ?>;">

                <div>
                    <?php if ($hasIssues) { ?>
                        <div class="warning">
                            <div><i class="fa-solid fa-triangle-exclamation fa-2x" style="opacity:0.5"></i></div>
                            <div style="padding: 0px 20px 0px 20px;font-weight: 300;">
                                There is some issue in your web hosting. Check the Test Results below and resolve the issues.
                                You can click the <span class="bt-red">[START TEST]</span> button again for repeating the tests.
                            </div>
                        </div>
                    <?php } else { ?>
                        <div class="success">
                            <div><i class="fa-solid fa-circle-check fa-2x" style="opacity:0.5"></i></div>
                            <div style="padding: 0px 20px 0px 20px;font-weight: 300;">
                                Your web hosting looks working correctly. Now you can install <b>UniDB</b> in your Server.
                                Click the <span class="bt-green">[INSTALL]</span> button for starting the installation.
                            </div>
                            <div>
                                <button class="btInstall" onclick="install()">INSTALL</button>
                            </div>
                        </div>
                    <?php } ?>
                </div>

                <div>TEST RESULTS</div>
                <div class="row1">
                    <div>Action</div>
                    <div>Result</div>
                    <div>Description</div>
                </div>

                <?php
                $index = 0;
                foreach ($test as $t) {
                    $index++;
                    if ($index % 2) $color = "#222222";
                    else $color = "#2b2b2b";
                ?>

                    <div class="row1" style="background-color: <?= $color ?>;">
                        <div style="color:#029ece"><?= $t[0] ?></div>
                        <div><?= ($t[1]) ? "<i class='fa-solid fa-check' style='color: #00d200;'></i>" : "<i class='fa-solid fa-xmark' style='color:#ff4e4e'></i>" ?></div>
                        <div><?= ($t[1]) ? $t[2] : str_replace(["(1)", "(2)", "(3)"], ["<up>(1)</up>", "<up>(2)</up>", "<up>(3)</up>"], $t[3]) ?></div>
                    </div>

                <?php
                }
                ?>

                <div style="padding:8px;font-size:12px;border-radius:0px 0px 4px 4px;flex-direction: column;background-color: #3c3c3c;">
                    <?php if ($hasIssues) { ?>
                        <div>
                            <b style="color:orange;">1. CAN'T READ / WRITE</b><br>
                            Probably there is a writing/reading Permissions (CHMOD) issue in this folder or in your web space. Check this folder Permissions; usually it should be set to 755.
                            <br><br>
                        </div>
                        <div>
                            <b style="color:orange;">2. getallheader() METHOD MISSING</b><br>
                            The PHP getallheaders() method is used for fetching the HTTP Requests' header. Without it, your Unity project can't communicate with UniDB. In some custom PHP configurations it may not be available; check you PHP installation in order to make this method available.
                            <br>
                        </div>
                        <br>
                        <div>
                            <b style="color:orange;">3. UNSECURE PHP VERSION</b><br>
                            You Server / WebHosting must have PHP version 7.4.0 or above. Your current version may have some vulnerabilities; so it's not considered secure. Upgrade your PHP version.
                        </div>
                    <?php } else { ?>
                        Everything looks working correctly!
                    <?php } ?>
                </div>
            </div>

        </div>


        <div class="body" style="display: <?= ($page == "START") ? "flex;flex-direction:row;" : "none" ?>;">

            <div class="install-info">
                <div class="title"><i class="fa-solid fa-server"></i> <b>SYSTEM INSTALLATION</b></div>
                <div>
                    I'm going to install the <b>UniDB</b> Server App. The installation will perform the following operations:
                    <ul>
                        <li style="margin-bottom: 10px;">The <b>install.php</b> file will be <b>renamed randomly</b> to avoid its accidental execution or an unauthorized access attempt.</li>
                        <li>The provided <b>username</b> and <b>password</b> will be used for creating an <b>Admin account</b>.</li>
                    </ul>
                    Once installation is complete, you will be redirected to the <b>login page</b> to access your <b>Admin Panel</b>.<br><br>
                    <div style="border-bottom: 1px solid #555;margin-bottom: 18px;"></div>
                    <span style="color:#ffca86;"><i class="fa-solid fa-triangle-exclamation"></i> Take note of the login page <b>URL</b> because it will be generated randomly to ensure a higher level of security.</span>
                </div>
            </div>

            <div style="width:530px;">
                <div class="title title2"><i class="fa-solid fa-user"></i> <b>ADMIN ACCOUNT</b></div>
                <div class="desc">
                    Enter a username and password in the fields below and click the <span class="bt-blue">[START INSTALLATION]</span> button to complete the installation procedure.
                </div>

                <div class="form">
                    <label>USERNAME</label>
                    <div class="desc">
                        <div>It must:</div>
                        <div>• contain only letters, numbers, and the following symbols are allowed: _ . @</div>
                        <div>• have a minimum length of 6 characters</div>
                    </div>
                    <div style="position: relative;">
                        <input type="text" id="username">
                        <div class="icon"><i class="fa-solid fa-user"></i></div>
                    </div>
                    <br>
                    <label>PASSWORD</label>
                    <div class="desc">
                        <div>It must:</div>
                        <div>• not contain spaces</div>
                        <div>• contain at least one uppercase letter, one lowercase letter, one symbol, and one number</div>
                        <div>• contain only the following symbols: $ ! % * ? & _ . @</div>
                        <div>• have a minimum length of 8 characters</div>
                    </div>
                    <div style="position: relative;">
                        <input type="password" id="password">
                        <div class="icon"><i class="fa-solid fa-key"></i></div>
                    </div>
                    <div style="font-size: 14px;margin-top: 10px;">Repeat the Password:</div>
                    <div style="position: relative;">
                        <input type="password" id="password2">
                        <div class="icon"><i class="fa-solid fa-key"></i></div>
                    </div>
                </div>

                <button onclick="startInstallation()">START INSTALLATION</button>
            </div>

            <script>
            <?php if ($action == "INSTALL") { ?>
            $(document).ready(() => {
            <?php if ($folderNewName != "" && strlen($folderNewName) == 10 && $folderRename && $adminFile) { ?>
                var URL = window.location.href;
                URL = URL.substr(0, URL.indexOf("install.php?"));
                var newURL = URL + "<span style='color:#e36000'><?=$folderNewName?></span>";
                ok("INSTALLATION COMPLETED", 
                "Your <b>Admin Panel</b> is ready to be used!<br><br>The installer has generated this URL, that is your Admin Panel URL:<br><br><span style='color:#048b00;'>" + newURL + "</span><br><br>Take note of it!",
                () => {
                    window.location = URL + "<?=$folderNewName?>";
                });
            <?php } else { ?>
                ok("INSTALLATION FAILED", "Something goes wrong during the Admin Panel installation.");
            <?php } ?>
            });
            <?php } ?>
            </script>

        </div>



    </div>
</body>

</html>

<script>
    function start() {
        window.location = "install.php?action=TEST";
    }

    function install() {
        window.location = "install.php?action=START";
    }

    function startInstallation() {

        var user = $("#username").val();
        var pass1 = $("#password").val();
        var pass2 = $("#password2").val();

        var userRules = /^[\w&_.@]+$/;
        var passRules = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_.])[A-Za-z\d@$!%*?&_.]{8,}$/;

        if (user == "" || user.length < 6)
            error("USERNAME TOO SHORT", "The username must have a minimum lenght of 6 characters.");
        else if (pass1 == "" || pass1.length < 8)
            error("PASSWORD TOO SHORT", "The password must have a minimum lenght of 8 characters.");
        else if (pass1.indexOf(" ") >= 0)
            error("PASSWORD CONTAINS SPACES", "The password can't contain the space character.");
        else if (!user.match(userRules))
            error("USERNAME NOT VALID", "The username doesn't respect the given rules.");
        else if (!pass1.match(passRules))
            error("PASSWORD NOT VALID", "The password doesn't respect the given rules.");
        else if (pass1 != pass2)
            error("PASSWORDS NOT MATCHING", "The two passwords must be equal.");
        else {
            window.location = "install.php?action=INSTALL&u=" + btoa(user) + "&p=" + btoa(pass1);
        }


    }

    $(document).ready(() => {

        var borderOK = "#555";
        var borderER = "#ff6060";

        $("#username").on('input', function(e) {
            var user = $("#username").val();
            var userRules = /^[\w&_.@]+$/;
            var error = false;

            if (user == "" || user.length < 6)
                error = true;
            else if (!user.match(userRules))
                error = true;

            $("#username").css("border-color", (error) ? borderER : borderOK);

        });

        $("#password").on('input', function(e) {
            var pass1 = $("#password").val();
            var passRules = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_.])[A-Za-z\d@$!%*?&_.]{8,}$/;
            var error = false;

            if (pass1 == "" || pass1.length < 8)
                error = true;
            else if (pass1.indexOf(" ") >= 0)
                error = true;
            else if (!pass1.match(passRules))
                error = true;

            $("#password").css("border-color", (error) ? borderER : borderOK);
        });

        $("#password2").on('input', function(e) {
            var pass1 = $("#password").val();
            var pass2 = $("#password2").val();
            var error = false;

            if (pass1 != pass2) error = true;

            $("#password2").css("border-color", (error) ? borderER : borderOK);
        });

    });

    function error(title, text) {
        Swal.fire({
            icon: 'error',
            title: title,
            text: text
        })
    }

    function ok(title, text, f = null) {
        Swal.fire({
            icon: 'success',
            title: title,
            html: text
        }).then(() => {
            if (f != null) f();
        });
    }
</script>