<?php

include_once("core.php");

switch ($CORE["extra"]) {
    case 'COUNT':

        $result = $database->count($CORE["dbTable"], $CORE["where"]);
        OK($result, $database->last());
        break;

    case 'MAX':

        $result = $database->max($CORE["dbTable"], $CORE["column"], $CORE["where"]);
        OK($result, $database->last());
        break;

    case 'MIN':

        $result = $database->min($CORE["dbTable"], $CORE["column"], $CORE["where"]);
        OK($result, $database->last());
        break;

    case 'AVG':

        $result = $database->avg($CORE["dbTable"], $CORE["column"], $CORE["where"]);
        OK($result, $database->last());
        break;

    case 'SUM':

        $result = $database->sum($CORE["dbTable"], $CORE["column"], $CORE["where"]);
        OK($result, $database->last());
        break;

    case 'EXISTS':

        $result = $database->has($CORE["dbTable"], $CORE["where"]);
        OK($result ? 1 : 0, $database->last());
        break;

    case 'REPLACE':

        $result = $database->replace($CORE["dbTable"], $CORE["join"], $CORE["where"]);
        OK($result->rowCount(), "REPLACE");
        break;

    case 'DROP':

        $database->drop($CORE["dbTable"]);
        OK(1, $database->last());
        break;

    default:
        # code...
        break;
}

OK("", $database->last());
