<?php

include_once("core.php");

if ($CORE["join"] == null)
    $data = $database->select($CORE["dbTable"], $CORE["what"], $CORE["where"]);
else
    $data = $database->select($CORE["dbTable"], $CORE["join"], $CORE["what"], $CORE["where"]);

OK($data, $database->last());
