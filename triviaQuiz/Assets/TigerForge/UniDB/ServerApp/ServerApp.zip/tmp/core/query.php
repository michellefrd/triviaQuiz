<?php

include_once("core.php");

$result = $database->query($CORE["extra"], $CORE["where"])->fetchAll();

OK($result, $database->last());

