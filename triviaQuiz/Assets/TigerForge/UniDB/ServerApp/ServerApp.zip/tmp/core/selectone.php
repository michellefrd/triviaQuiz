<?php

include_once("core.php");

if ($CORE["join"] == null)
    $data = $database->get($CORE["dbTable"], $CORE["what"], $CORE["where"]);
else
    $data = $database->get($CORE["dbTable"], $CORE["join"], $CORE["what"], $CORE["where"]);

OK($data, $database->last());
