<?php

include_once("core.php");

$result = $database->insert($CORE["dbTable"], $CORE["data"]);

OK($database->id(), $database->last());

