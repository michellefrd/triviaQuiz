<?php

include_once("core.php");

$result = $database->delete($CORE["dbTable"], $CORE["where"]);

if ($result->errorCode() == "00000") {
    OK($result->rowCount(), $database->last());
}
else 
{
    ERROR($result->errorInfo(), $result->errorCode());
}

