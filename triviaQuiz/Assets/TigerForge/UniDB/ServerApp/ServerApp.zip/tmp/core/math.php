<?php

include_once("core.php");

$exists = $database->has($CORE["dbTable"], $CORE["where"]);

if ($exists)
{
    $col = array_key_first($CORE["data"]);
    $formula = $CORE["data"][$col];

    $data = $database->get($CORE["dbTable"], $col, $CORE["where"]);

    $formula = str_replace("x", "X", $formula);
    $formula = str_replace("X", $data, $formula);

    $newValue = 0;
    eval("\$newValue = $formula;");

    $CORE["data"][$col] = $newValue;

    $result = $database->update($CORE["dbTable"], $CORE["data"], $CORE["where"]);

    OK($result->rowCount(), $database->last());

}
else {
    OK(0, $database->last());
}


