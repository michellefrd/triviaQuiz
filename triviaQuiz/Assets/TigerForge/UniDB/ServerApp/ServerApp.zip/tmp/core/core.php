<?php

include_once("../Medoo.php");
include_once("../sys/profiles.php");
include_once("../admin.php");

use Medoo\Medoo;

try {

    $CORE = [];

    $_data = file_get_contents("php://input");
    $_data = json_decode($_data);

    $_header = array_change_key_case(getallheaders(), CASE_LOWER);
    $CORE["token"] = $_header["token"];

    $CORE["dbID"]       = $_data->dbID;
    $CORE["dbTable"]    = $_data->dbTable;
    $CORE["what"]       = $_data->what == "*" ? "*" : explode(",", $_data->what);
    $CORE["where"]      = $_data->where == "" ? null : json_decode($_data->where, true);
    $CORE["data"]       = $_data->data == "" ? null : json_decode($_data->data, true);
    $CORE["join"]       = $_data->join == "" ? null : json_decode($_data->join, true);
    $CORE["extra"]      = $_data->extra;
    $CORE["column"]     = $_data->column;

    if (is_array($CORE["what"]) && contains($_data->what, "{{")) $CORE["what"] = finalizeWhat($CORE["what"]);
    if ($CORE["where"] != null && contains($_data->where, "{{")) $CORE["where"] = finalizeWhere($CORE["where"]);
    if ($CORE["data"] != null && contains($_data->data, "{{")) $CORE["data"] = finalizeWhere($CORE["data"]);

    $config = [
        'type' => $PROFILE[$CORE["dbID"]]["type"],
        'host' => $PROFILE[$CORE["dbID"]]["host"],
        'database' => $PROFILE[$CORE["dbID"]]["name"],
        'username' => $PROFILE[$CORE["dbID"]]["user"],
        'password' => $PROFILE[$CORE["dbID"]]["pass"],
        'error' => PDO::ERRMODE_SILENT
    ];
    if ($PROFILE[$CORE["dbID"]]["port"] != "") $config['port'] = $PROFILE[$CORE["dbID"]]["port"];
    if (isset($PROFILE[$CORE["dbID"]]["charset"])) {
        $config['charset'] = $PROFILE[$CORE["dbID"]]["charset"];
        $config['collation'] = $PROFILE[$CORE["dbID"]]["collation"];
    } else {
        $config['charset'] = "utf8mb4";
        $config['collation'] = "utf8mb4_general_ci";
    }

    $database = new Medoo($config);
} catch (\Throwable $th) {
    ERROR("Core initialization failed: $th", "000");
}

function finalizeWhat($what)
{
    $newArray = array();
    foreach ($what as $w) {
        if (startsWith($w, "{{") && endsWith($w, "}}")) {
            $w = trim(trim($w, "{"), "}");
            $tmp = explode("|", $w);
            $newArray[$tmp[0]] = Medoo::raw($tmp[1]);
        }
        else 
        {
            $newArray[] = $w;
        }
    }
    return $newArray;
}

function finalizeWhere($where)
{
    foreach ($where as $key => $value)
    {
        if (is_array($value))
        { 
            $where[$key] = finalizeWhere($value); 
        }
        else
        {
            if (startsWith($value, "{{") && endsWith($value, "}}")) {
                $w = trim(trim($value, "{"), "}");
                $where[$key] = Medoo::raw($w);
            }
        }
    }
    return $where;
}

function OK($data, $query, $code = "", $error = "")
{
    $response = [];
    $response["status"] = "OK";
    $response["data"] = json_encode($data);
    $response["query"] = $query;
    $response["error"] = $error;
    $response["code"] = $code;

    die(Encrypt(json_encode($response)));
}

function ERROR($error, $code = "", $data = "")
{
    $response = [];
    $response["status"] = "ERROR";
    $response["data"] = $data;
    $response["query"] = "";
    $response["error"] = $error;
    $response["code"] = $code;

    die(Encrypt(json_encode($response)));
}

function Encrypt($plaintext)
{
    global $_U;
    $key2 = substr($_U["key"], 0, 16);
    $encrypted = base64_encode(openssl_encrypt($plaintext, 'aes-256-cbc', $_U["key"], OPENSSL_RAW_DATA, $key2));
    return $encrypted;
}

function Decrypt($encrypted)
{
    global $_U;
    $key2 = substr($_U["key"], 0, 16);
    $decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $_U["key"], OPENSSL_RAW_DATA, $key2);
    return $decrypted;
}

function startsWith($string, $what)
{
    $length = strlen($what);
    return substr($string, 0, $length) === $what;
}

function endsWith($string, $what)
{
    $length = strlen($what);
    if (!$length) {
        return true;
    }
    return substr($string, -$length) === $what;
}

function contains($string, $what) {
    return (strpos($string, $what) !== false);
}