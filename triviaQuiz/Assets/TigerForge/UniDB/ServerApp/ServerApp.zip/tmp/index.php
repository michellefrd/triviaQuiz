<?php
$_VERSION = "1.2";
$_Extensions = get_loaded_extensions();
?>

<!doctype html>
<html>

<head>
    <title>TigerForge™ UniDB | ADMIN PANEL</title>
    <link rel="icon" type="image/x-icon" href="../favicon.ico">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/themes/base/jquery-ui.min.css" integrity="sha512-ELV+xyi8IhEApPS/pSj66+Jiw+sOT1Mqkzlh8ExXihe4zfqbWkxPRi8wptXIO9g73FSlhmquFlUOuMSoXz5IRw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.css" />
    <link rel="stylesheet" href="style.css" />

    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js" integrity="sha512-57oZ/vW8ANMjR/KQ6Be9v/+/h6bq9/l3f0Oc7vn6qMqyhvPd1cvKBRWWpzu0QoneImqr2SkmO4MSqU+RpHom3Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.37/dist/sweetalert2.min.js"></script>
    <script src="core.js"></script>
</head>

<body>
    <div id="pageAdminPanel" class="page" style="display:none;">
        <div class="banner banner-fixed">
            <div>
                <i class="fa-solid fa-screwdriver-wrench fa-3x"></i>
            </div>
            <div>
                <div style="display:flex;width: 100%;justify-content: space-between;">
                    <span><span>UniDB</span> Admin Panel</span>
                    <button onclick="modalOpen('modalSystemInfo')" class="bt-system-info">SYSTEM INFO</button>
                </div>
            </div>
            <div>
                <div>v.<?= $_VERSION ?></div>
            </div>
        </div>

        <div class="panel" style="margin-top: 90px;">
            <div class="title">
                <i class="fa-solid fa-database"></i>
                <span>Your Databases</span>
                <button onclick="modalOpen('modalAddDatabase')"><i class="fa-solid fa-plus"></i> ADD</button>
            </div>
            <div class="dblist">
                <table>
                </table>
            </div>
            <div class="footer">
                Click the [+ ADD] button for adding and configuring all the Databases your Unity project can work with.
            </div>
        </div>

        <div id="code-generation" style="display:none;margin-top:-20px;">

            <div class="panel">
                <div class="title">
                    <i class="fa-brands fa-unity"></i>
                    <span>Your Unity Settings</span>
                    <button onclick="generate()"><i id="generatestatus" class="fa-solid fa-arrows-rotate"></i> GENERATE</button>
                </div>
                <div class="unity-alert">
                    <div><i class="fa-solid fa-triangle-exclamation fa-2x"></i></div>
                    <div style="font-size: 12px;">You must <b>generate</b> and <b>copy</b> the <b>Unity Settings</b> C# script below into your Unity project, inside the provided asset's <b>UniDBConfig.cs</b> file.<br>
                        You must do it everytime you:<br>
                        • add a new <b>Database</b>;<br>
                        • add/modify your Databases' <b>Tables</b>;<br>
                        • change something in your Database's profile above.
                    </div>
                </div>
                <div class="unity">
                    <div class="copy" onclick="CopyText('csharpcode')"><i class="fa-regular fa-copy"></i> COPY TEXT</div>
                    <textarea id="csharpcode"></textarea>
                </div>
                <div class="footer">
                    Click the [<i class="fa-solid fa-arrows-rotate"></i> GENERATE] button for generating an updated versione of the Unity Settings script.
                </div>
            </div>

        </div>
    </div>

    <div id="pageLogin" class="page">
        <div class="login">
            <div>
                <div class="header">Admin Login</div>
                <div class="desc">Enter your credentials for accessing the Admin Panel.</div>
                <div class="row">
                    <div>Username</div>
                    <input type="text" id="username">
                    <div class="icon"><i class="fa-solid fa-user"></i></div>
                </div>
                <div class="row">
                    <div>Password</div>
                    <input type="password" id="password">
                    <div class="icon"><i class="fa-solid fa-key"></i></div>
                </div>
                <div>
                    <button onclick="login()">LOGIN</button>
                </div>
            </div>
        </div>
    </div>


    <div id="modalAddDatabase" title="New Database Profile">
        <table>
            <tr>
                <td>
                    <div>Type*</div>
                    <div>The type of your Database.</div>
                </td>
                <td>
                    <select id="dbType" style="color: #66b8ff;" onchange="addDatabaseFormManager('dbtype')">
                        <option value="mysql" selected>MySQL</option>
                        <option value="mariadb">MariaDB</option>
                        <option value="sqlite">SQLite</option>
                        <option value="pgsql">PostgreSQL</option>
                        <option value="mssql">MSSQL</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="border-bottom: 1px solid #636363;"></td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top: 10px;font-size: 14px;font-style: italic;">
                Fill-in the Form below with the parameters necessary to open a connection with your Database. Which fields to fill-in depends on the type of your Database and how you configured it.
                </td>
            </tr>
            <tr id="db_name">
                <td>
                    <div>Name*</div>
                    <div id="db_name_help">The name of your Database.</div>
                </td>
                <td><i class="fa-solid fa-circle-info"></i><input id="dbName" type="text"></td>
            </tr>
            <tr id="db_host">
                <td>
                    <div>Host</div>
                    <div>Where your Database is located.</div>
                </td>
                <td>
                <i class="fa-solid fa-circle-info"></i><input id="dbHost" style="color: #CCC;" type="text">
                </td>
            </tr>
            <tr id="db_username">
                <td>
                    <div>Username</div>
                    <div>The username for accessing your Database.</div>
                </td>
                <td><i class="fa-solid fa-circle-info"></i><input id="dbUser" style="color: #ffd17e;" type="text"></td>
            </tr>
            <tr id="db_password">
                <td>
                    <div>Password</div>
                    <div>The password for accessing your Database.</div>
                </td>
                <td><i class="fa-solid fa-circle-info"></i><input id="dbPass" style="color: #ffd17e;" type="text"></td>
            </tr>
            <tr id="db_port">
                <td>
                    <div>Port</div>
                    <div>The Port of your Database.</div>
                </td>
                <td>
                <i class="fa-solid fa-circle-info"></i><input id="dbPort" style="color: #CCC;" type="text">
                </td>
            </tr>
            <tr id="db_charset">
                <td>
                    <div>Chars Systems</div>
                    <div>The system for the chars management.</div>
                </td>
                <td>
                <i class="fa-solid fa-circle-info" style="margin-right:6px;"></i>
                <input id="dbCharset" style="color:#a5dc86;width:30%;" type="text">
                <i class="fa-solid fa-circle-info" style="margin-left:15px;"></i>
                <input id="dbCollation" style="color:#a5dc86;width:48%;" type="text">
                </td>
            </tr>
        </table>

        <div style="margin-top:30px;display: flex;justify-content: space-between;">
            <button onclick="addDatabase()" class="btn"><i class="fa-solid fa-floppy-disk"></i>&nbsp;&nbsp;SAVE</button>
            <button onclick="testDatabase()" class="btn btn-blue" style="margin-right:4px;"><i class="fa-solid fa-rotate"></i>&nbsp;&nbsp;TEST</button>
            <input type="hidden" id="dbID">
        </div>
    </div>


    <div id="modalSystemInfo" title="System Information">
        <table style="font-size: 14px;" class="php-ext-table">
            <tr>
                <td>Current PHP version:</td>
                <td><?= phpversion() ?></td>
                <td rowspan="9" style="vertical-align: top;">
                    <div style="color: #688cac;">Installed PHP Extensions</div>
                    <div class="php-exts"><?php 
                        foreach ($_Extensions as $ext) echo (strpos(strtolower($ext), "pdo") !== false || strpos(strtolower($ext), "sql") !== false) ? "<span style='color:orange;'>$ext</span><br>" : "$ext<br>";
                    ?></div>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td></td>
            </tr>
            <tr>
                <td>MySQL / MariaDB PDO Support:</td>
                <td><?= (in_array("pdo_mysql", $_Extensions) ? "<span class='yes'>YES</span>" : "<span class='yes'>NO</span>") ?></td>
                <td></td>
            </tr>
            <tr>
                <td>PostreSQL PDO Support:</td>
                <td><?= (in_array("pdo_pgsql", $_Extensions) ? "<span class='yes'>YES</span>" : "<span class='yes'>NO</span>") ?></td>
                <td></td>
            </tr>
            <tr>
                <td>SQLite PDO Support:</td>
                <td><?= (in_array("pdo_sqlite", $_Extensions) ? "<span class='yes'>YES</span>" : "<span class='yes'>NO</span>") ?></td>
                <td></td>
            </tr>
            <tr>
                <td>MSSQL PDO Support:</td>
                <td><?= (in_array("pdo_sqlsrv", $_Extensions) ? "<span class='yes'>YES</span>" : "<span class='yes'>NO</span>") ?></td>
                <td></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td></td>
            </tr>
            <tr>
                <td>POST max size:</td>
                <td><?= ini_get('post_max_size') . "" ?></td>
                <td></td>
            </tr>
            <tr>
                <td>Memory limit:</td>
                <td><?= ini_get('memory_limit') . "" ?></td>
                <td></td>
            </tr>
        </table>
    </div>


</body>

</html>

<script>
    $(document).ready(() => {

    });
</script>